import numpy as np

print(', '.join(np.random.randint(1990,2022,5).astype(str)))